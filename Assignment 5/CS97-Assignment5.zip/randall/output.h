#include <stdbool.h>

bool
writebytes (unsigned long long x, int nbytes);